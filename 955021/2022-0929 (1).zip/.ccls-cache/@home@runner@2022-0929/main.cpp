#include <iostream>
using namespace std;

int main() {
  int num1, num2,num3;
  cout << "你要多少減多少減多少";
  cin >> num1 >> num2>>num3;
  cout << "答案是"<<num1 - num2-num3;
  /*cout << "你叫甚麼名子";
  string frist_name,last_name;
  cin>>frist_name>>last_name;

  cout<<"你好"<<frist_name<<" "<<last_name;*/
}